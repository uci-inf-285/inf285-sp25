//TODO: print out all odd numbers less than 20
//First, count up the loop variable by two every time
for(let i = 1; i < 20; i = i + 2) {
    console.log(i);
}
//Then, have i go from 1-10, but use multiplication and subtraction to print every other number
for(let i = 1; i <= 10; i = i + 1) {
    console.log(i * 2 - 1);
}