//Jenny is 64 years old. Is she eligible for medicare?
let jenny = 64;
console.log("Jenny is " + jenny);
//TODO: add *if* statement to check her age, and print "eligible" if she's eligible

//TODO: It's Jenny's birthday! Add one to her age

console.log("Jenny is " + jenny);
//TODO: check again if she is eligible, and print "eligible" if she is