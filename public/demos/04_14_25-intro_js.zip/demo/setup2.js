//TODO: print out a 5x5 times table by row.
//First, print out each number on its own line.
//Then, try to build up the times table by rows, and print one row at a time.
//Finally, align the columns. Add an extra space if the multipliation is one digit.