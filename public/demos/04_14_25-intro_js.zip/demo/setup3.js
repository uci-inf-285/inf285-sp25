//TODO: print out all odd numbers less than 20
//First, count up the loop variable by two every time

//Then, have i go from 1-10, but use multiplication and subtraction to print every other number
