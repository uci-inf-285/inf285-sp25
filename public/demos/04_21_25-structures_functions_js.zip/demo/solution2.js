function calculateCost(price, numberToPurchase) {
    return price * numberToPurchase;
}

function calculateTotal(items) {
    let totalCost = 0;

    for(let item of items) {
        console.log('Spending ' + calculateCost(item.price, item.numberToPurchase) + ' on ' + item.name);
        totalCost = totalCost + calculateCost(item.price, item.numberToPurchase);
    }

    return totalCost;
}

let groceryItems = [
    {'name':'Apple', 'price': 1.25, 'numberToPurchase': 6},
    {'name':'Orange', 'price': 0.99, 'numberToPurchase': 12},
    {'name':'Bread', 'price': 4.53, 'numberToPurchase': 1}
];

console.log('Total cost: ' + calculateTotal(groceryItems));

groceryItems.push({'name':'Cake', 'price':20.89, 'numberToPurchase': 2});

console.log('Total cost: ' + calculateTotal(groceryItems));