let shoppingItems = [];

function call() {

}

function addItem() {
    //TODO: Update the shopping items array with the new item
    //TODO: Add a new list item (<li>) to the shopping list with the value entered in the text box
    //TODO: Clear the text box after entry
    //TODO: Prevent entering empty items
    
}