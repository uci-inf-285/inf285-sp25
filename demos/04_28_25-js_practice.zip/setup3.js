let muppetShoppingList = { "Apple": 5, "Cookie": 1002, "Pear": 6, "Eggs": 36, "Broccoli": 4, "Fish": 2, "Milk": 3, "Coconut": 3, "Cereal": 1};

//TODO: Do the Muppets have what they need to make a recipe? If so, print that they have everything they need
// If not, print out what ingredients they still need.
// Make sure to multiply by the number of portions! This can be a whole number, or a decimal
function checkForMissingIngredients(recipeName, recipe, ingredients, numPortions) {
    let haveAllIngredients = true;
    if(haveAllIngredients) {
        console.log('We have everything we need to make ' + recipeName + '!');
    } else {
        console.log('Uh oh, we\'re missing ingredients for ' + recipeName + '.');
        // Print out what ingredients they still need.
    }
}

checkForMissingIngredients('Cookies and Milk', {'Cookie': 2, 'Milk': 1}, muppetShoppingList, 2);
checkForMissingIngredients('Fruit & Veggie Salad', {'Apple': 1, 'Broccoli': 1, 'Tomato': 2}, muppetShoppingList, 1);
checkForMissingIngredients('Coconut Cereal Bars', {'Eggs': 4, 'Coconut': 1, 'Cereal': 2}, muppetShoppingList, 0.25);