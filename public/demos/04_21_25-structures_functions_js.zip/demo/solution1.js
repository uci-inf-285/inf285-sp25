function calculateAverageGrade(grades) {
    let gradeTotal = 0;

    //Can also write this as a for... of loop
    for(let i = 0; i < grades.length; i = i + 1) {
        gradeTotal = gradeTotal + grades[i];
    }
    return gradeTotal / grades.length;
}

let studentAGrades = [70, 95, 84, 100, 92, 94];
let studentBGrades = [91, 94, 96, 99, 95, 89];

console.log('Average grade for Student A: ' + calculateAverageGrade(studentAGrades));
console.log('Average grade for Student B: ' + calculateAverageGrade(studentBGrades));