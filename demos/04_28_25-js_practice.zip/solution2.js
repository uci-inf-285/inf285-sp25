let muppetShoppingList = { "Apple": 5, "Cookie": 1002, "Pear": 6, "Eggs": 36, "Broccoli": 4, "Fish": 2, "Milk": 3, "Coconut": 3, "Cereal": 1};

//Had to add "pear" to our list of fruits
let foodGroups = {'Fruits': ['Apple', 'Orange', 'Banana', 'Pear'], 'Vegetables': ['Spinach', 'Pepper', 'Broccoli'], 'Grains': ['Bread', 'Cereal', 'Oats'], 'Protein': ['Beef', 'Chicken', 'Fish'], 'Dairy': ['Eggs', 'Milk'], 'Dessert': ['Cake', 'Cookie']};

//TODO: Count how many of each food group the Muppets want from the store. Note that there are items in each food group which aren't on our shopping list!
for(let group of Object.keys(foodGroups)) {
    let totalOfGroup = 0;
    for(let item of foodGroups[group]) {
        if(item in muppetShoppingList) {
            totalOfGroup = totalOfGroup + muppetShoppingList[item];
        }
    }
    console.log(group + ': ' + totalOfGroup);
}