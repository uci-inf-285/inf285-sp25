//TODO: Write function to calculate and return the average from an array of grades
function calculateAverageGrade(grades) {
    
}

let studentAGrades = [70, 95, 84, 100, 92, 94];
let studentBGrades = [91, 94, 96, 99, 95, 89];

//TODO: First, create a for loop to calculate the average grade for studentA and print it below

//TODO: Update log statements to print averages for each student
console.log('Average grade for Student A: ');
console.log('Average grade for Student B: ');