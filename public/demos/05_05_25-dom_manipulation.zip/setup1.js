function call() {
    //TODO: Give the page a new title

    //TODO: Update the "not blue" tag with HTML, containing an em tag

    //TODO: Update all paragraph tags to have the class "arial"

}