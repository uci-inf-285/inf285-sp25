let shoppingItems = [];

function call() {

}

function addItem() {
    //TODO: Update the shopping items array with the new item
    //TODO: Add a new list item (<li>) to the shopping list with the value entered in the text box
    //TODO: Clear the text box after entry
    //TODO: Prevent entering empty items
    let shoppingItem = document.getElementById('newItem');
    if(shoppingItem.value) {
        shoppingItems.push(shoppingItem.value);
        shoppingItem.value = '';
    }
    let shoppingList = document.getElementById('shoppingList');
    shoppingList.innerHTML = '';
    for(item of shoppingItems) {
        shoppingList.innerHTML = shoppingList.innerHTML + '<li>' + item + '</li>';
    }
}