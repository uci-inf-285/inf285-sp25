//TODO: print out a 5x5 times table by row.
//First, print out each number on its own line.
//Then, try to build up the times table by rows, and print one row at a time.
//Finally, align the columns. Add an extra space if the multipliation is one digit.
for(let i=1; i <= 5; i = i + 1) {
    let row = "";
    for(let j = 1; j <= 5; j = j + 1) {
        if(i*j >= 10) {
            row = row + i*j + " ";
        } else {
            row = row + i*j + "  ";
        }
    }
    console.log(row);
}