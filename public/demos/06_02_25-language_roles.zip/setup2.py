#JSON downloaded from https://programs.sigchi.org/chi/2025
import json
import matplotlib.pyplot as plt
import numpy as np

program = json.load(open('CHI_2025_program.json'))
papers = program['contents']
#TODO: With numpy, calculate the minimum, maximum, mean, and standard deviation of the number of authors per paper


#TODO: With matplotlib, graph a histogram showing the distribution of the number of authors on each CHI paper

