function sayHi() {
    let nameField = document.getElementById('name');
    let para = document.getElementById('hi');
    para.textContent = 'Hi, ' + nameField.value + '!';
}