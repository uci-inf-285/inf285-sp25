let studentGrades = {
    'Ash Ketchum': [70, 95, 84, 81, 92, 94],
    'Cersei Lannister': [90, 58, 82],
    'Janine Teagues': [91, 94, 96, 99, 95, 98],
    'Jean-Luc Picard': [64, 87, 91, 72]
};

//TODO: Janine got a 100 on her recent assignment! Add it to the end of her grades.


//TODO: Calculate the average assignment grade for each student, as well as the overall average on all assignments
//Notice that not all students have the same number of grades!
