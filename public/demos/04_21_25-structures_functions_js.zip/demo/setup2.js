//TODO: Write a function to calculate the cost of a grocery item
function calculateCost(price, numberToPurchase) {
    
}

//TODO: Write a function to calculate the total cost of all grocery items
function calculateTotal(items) {

}

let groceryItems = [
    {'name':'Apple', 'price': 1.25, 'numberToPurchase': 6},
    {'name':'Orange', 'price': 0.99, 'numberToPurchase': 12},
    {'name':'Bread', 'price': 4.53, 'numberToPurchase': 1}
];

console.log('Total cost: ' + calculateTotal(groceryItems));

groceryItems.push({'name':'Cake', 'price':20.89, 'numberToPurchase': 2});

console.log('Total cost: ' + calculateTotal(groceryItems));