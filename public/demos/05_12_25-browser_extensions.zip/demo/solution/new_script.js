console.log("Hello, world!");

let images = document.getElementsByTagName('img');
for(let image of images) {
    image.src = chrome.runtime.getURL("images/285.png");
}

let events = document.getElementsByClassName('event');
for(let event of events) {
    if(event.classList.contains('lecture') || event.classList.contains('demo')) {
        event.style.backgroundColor = '#DDDDDD';
    } else if(event.classList.contains('officehours_ziqi') || event.classList.contains('officehours_weijun') || event.classList.contains('officehours_daniel')) {
        event.style.backgroundColor = '#AAAAAA';
    } else if(event.classList.contains('assignment')) {
        event.style.backgroundColor = '#777777';
    } else if(event.classList.contains('absence') || event.classList.contains('holiday')) {
        event.style.backgroundColor = '#555555';
    }
}