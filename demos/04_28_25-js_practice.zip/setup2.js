let muppetShoppingList = { "Apple": 5, "Cookie": 1002, "Pear": 6, "Eggs": 36, "Broccoli": 4, "Fish": 2, "Milk": 3, "Coconut": 3, "Cereal": 1};

let foodGroups = {'Fruits': ['Apple', 'Orange', 'Banana'], 'Vegetables': ['Spinach', 'Pepper', 'Broccoli'], 'Grains': ['Bread', 'Cereal', 'Oats'], 'Protein': ['Beef', 'Chicken', 'Fish'], 'Dairy': ['Eggs', 'Milk'], 'Dessert': ['Cake', 'Cookie']};

//TODO: Count how many of each food group the Muppets want from the store. Note that there are items in each food group which aren't on our shopping list!
