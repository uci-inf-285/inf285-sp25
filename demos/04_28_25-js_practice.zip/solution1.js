//TODO: Merge Bert & Ernie's shopping lists together. If they both want a particular item, add how much they want together
let bertShoppingList = {'Apple': 5, 'Cookie': 3, 'Pear': 4, 'Eggs': 12};
let ernieShoppingList = {'Eggs': 24, 'Broccoli': 1, 'Fish': 2};

let bertAndErnieShoppingList = {};
for(let key of Object.keys(bertShoppingList)) {
    //Copy all of the items in Bert's shopping list over to Ernie's
    bertAndErnieShoppingList[key] = bertShoppingList[key];
}
//Then, loop over Ernie's shopping list
for(let key of Object.keys(ernieShoppingList)) {
    //If the key is already in the shopping list, add the value to the existing value. Otherwise, create a new key/value
    if(key in bertAndErnieShoppingList) {
        bertAndErnieShoppingList[key] = bertAndErnieShoppingList[key] + ernieShoppingList[key];
    } else {
        bertAndErnieShoppingList[key] = ernieShoppingList[key];
    }
}
console.log(bertAndErnieShoppingList);

//TODO: Turn your code into a function which merges two shopping lists. Then, use it to get a shopping list for all of the Muppets!
function mergeShoppingLists(listA, listB) {
    let mergedList = {};
    for(let key of Object.keys(listA)) {
        mergedList[key] = listA[key];
    }
    for(let key of Object.keys(listB)) {
        if(key in mergedList) {
            mergedList[key] = mergedList[key] + listB[key];
        } else {
            mergedList[key] = listB[key];
        }
    }
    return mergedList;
}

let cookieMonsterShoppingList = {'Cookie': 999, 'Milk': 1};
let elmoShoppingList = {'Coconut': 3, 'Cereal': 1, 'Pear': 2};
let bigBirdShoppingList = {'Milk': 2, 'Broccoli': 3};

let muppetShoppingList = {};
muppetShoppingList = mergeShoppingLists(muppetShoppingList, bertShoppingList);
muppetShoppingList = mergeShoppingLists(muppetShoppingList, ernieShoppingList);
//These lines can get merged together, though doing so can start to look messy!
muppetShoppingList = mergeShoppingLists(mergeShoppingLists(mergeShoppingLists(muppetShoppingList, cookieMonsterShoppingList), elmoShoppingList), bigBirdShoppingList);
console.log(muppetShoppingList);