#include <iostream>
using namespace std;

int main() {
    //TODO: look up zero in the character table, and assign that value to an integer
    //https://en.wikipedia.org/wiki/ASCII#Printable_character_table
    //Then, convert it to a variable of type char (character) and print it out
    int zero = 48;
    char zeroChar = zero;
    cout << "Hello, " << zeroChar << endl;
    //TODO: Add 2, 8, and 5 to print out 285
    char twoChar = zeroChar + 2;
    char eightChar = zeroChar + 8;
    char fiveChar = zeroChar + 5;
    cout << "Hello, " << twoChar << eightChar << fiveChar << endl;
    return 0;
}