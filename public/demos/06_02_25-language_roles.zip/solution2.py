#JSON downloaded from https://programs.sigchi.org/chi/2025
import json
import matplotlib.pyplot as plt
import numpy as np

program = json.load(open('CHI_2025_program.json'))
papers = program['contents']
#TODO: With numpy, calculate the minimum, maximum, mean, and standard deviation of the number of authors per paper
#When checking, quickly realized that papers with zero authors were not papers :-)
paper_author_count = [len(paper['authors']) for paper in papers if len(paper['authors']) > 0]
print('Minimum number of authors is ' + str(min(paper_author_count)) + ', max is ' + str(max(paper_author_count)))
print('Average number of authors is ' + str(np.mean(paper_author_count)) + ', standard deviation is ' + str(np.std(paper_author_count)))

#TODO: With matplotlib, graph a histogram showing the distribution of the number of authors on each CHI paper
fig, ax = plt.subplots(tight_layout=True)
ax.hist(paper_author_count, bins=30)

plt.show()