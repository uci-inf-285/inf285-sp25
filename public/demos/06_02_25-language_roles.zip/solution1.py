#TODO: parse the CHI 2025 program, write a CSV with all papers from UC Irvine
#JSON downloaded from https://programs.sigchi.org/chi/2025
#This is how we identified the articles/authors in this blog post: https://www.informatics.uci.edu/chi-2025/
import json
import csv
program = json.load(open('CHI_2025_program.json'))
papers = program['contents']
#See one_paper.json for an example of how a single paper is structured
UCI_papers = []
for paper in papers:
    is_UCI_paper = False
    for author in paper['authors']:
        for author_affiliations in author['affiliations']:
            if 'Irvine' in author_affiliations['institution']:
                is_UCI_paper = True
    if is_UCI_paper:
        UCI_papers.append(paper)

titlesAndDois = [{'id': paper['id'], 'title': paper['title'], 'doi': paper['addons']['doi']['url']} for paper in UCI_papers if 'addons' in paper and 'doi' in paper['addons']]

#Specify that we want to write a CSV with one column for paper ids, titles and a second for DOIs
dictWriter = csv.DictWriter(open('UCI_papers.csv', 'w'), fieldnames=['id', 'title', 'doi'])
dictWriter.writeheader()
dictWriter.writerows(titlesAndDois)