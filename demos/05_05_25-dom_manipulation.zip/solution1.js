function call() {
    //TODO: Give the page a new title
    let titleTag = document.getElementById('title');
    titleTag.textContent = 'This is a new title!';

    //TODO: Update the "not blue" tag with HTML, containing an em tag
    let notBluePara = document.getElementById('notblue');
    notBluePara.innerHTML = 'And <em>this</em> is new HTML.';

    //TODO: Update all paragraph tags to have the class "arial"
    let paraTags = document.getElementsByTagName('p');
    for(let para of paraTags) {
        para.classList.add('arial');
    }
}