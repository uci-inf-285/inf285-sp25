//TODO: Merge Bert & Ernie's shopping lists together. If they both want a particular item, add how much they want together
let bertShoppingList = {'Apple': 5, 'Cookie': 3, 'Pear': 4, 'Eggs': 12};
let ernieShoppingList = {'Eggs': 24, 'Broccoli': 1, 'Fish': 2};

//TODO: Turn your code into a function which merges two shopping lists. Then, use it to get a shopping list for all of the Muppets!

let bertAndErnieShoppingList = {};
console.log(bertAndErnieShoppingList);

let cookieMonsterShoppingList = {'Cookie': 999, 'Milk': 1};
let elmoShoppingList = {'Coconut': 3, 'Cereal': 1, 'Pear': 2};
let bigBirdShoppingList = {'Milk': 2, 'Broccoli': 3};

let muppetShoppingList = {};
console.log(muppetShoppingList);