let shoppingItems = [];
let boughtItems = [];

function call() {

}

function addItem() {
    //TODO: Change the innerHTML to add a checkbox inside of the list item
    let shoppingItem = document.getElementById('newItem');
    if(shoppingItem.value) {
        shoppingItems.push(shoppingItem.value);
        shoppingItem.value = '';
    }
    let shoppingList = document.getElementById('shoppingList');
    shoppingList.innerHTML = '';
    for(item of shoppingItems) {
        shoppingList.innerHTML = shoppingList.innerHTML + '<li><input type="checkbox" value="' + item + '" id="' + item + '">' + '<label for="' + item + '">' + item + '</label></li>';
    }
}

//Helper function to find a specific item within the shoppingItem array and remove it
//https://stackoverflow.com/questions/5767325/how-can-i-remove-a-specific-item-from-an-array-in-javascript
function removeShoppingItem(itemName) {
    let indexToRemove = shoppingItems.indexOf(itemName);
    if(indexToRemove > -1) {
        shoppingItems.splice(indexToRemove, 1);
    }
}

function checkOut() {
    //TODO: Get all checked checkboxes, add them to bought items, and remove them from shopping items
    let inputs = document.getElementsByTagName('input');
    for(let input of inputs) {
        if(input.type == 'checkbox' && input.checked) {
            boughtItems.push(input.value);
            removeShoppingItem(input.value);
        }
    }
    //TODO: Add all bought items to the list of bought items
    let boughtItemsId = document.getElementById('itemsBought');
    boughtItemsId.innerHTML = '';
    for(item of boughtItems) {
        boughtItemsId.innerHTML = boughtItemsId.innerHTML + '<li>' + item + '</li>';
    }
    //Call addItem to repopulate the list of shopping items
    addItem();
}